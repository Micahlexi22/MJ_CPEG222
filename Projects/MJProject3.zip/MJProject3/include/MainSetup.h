//**********************************************
// * Author: M. Johnson
// * CPEG222 Project 3, 9/26/26
// * NucleoF466ZE CMSIS 
// *
// * Project Description: 
// * Making a timer on SSD controlled by up and down controls.
//**********************************************

#include "stm32f4xx.h" // Needed for GPIO and RCC registers
#include <stdbool.h> // Enables boolean
#include "PinPortDefs.h"


void SSD_init(void);
void buttons_init(void);
void state_machine(void);


void rcc_enable(void);
void delay(volatile uint32_t count);
void SysTick_Handler(void);
void EXTI9_5_IRQHandler(void);
void TIM5_IRQHandler(void);
void refresh(uint16_t current_num);

