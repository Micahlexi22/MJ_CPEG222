//**********************************************
// * Author: M. Johnson
// * CPEG222 Project 3, 9/26/26
// * NucleoF466ZE CMSIS 
//**********************************************//
#include "stm32f4xx.h" 

//Buttons
#define LEFT_PIN 9
#define LEFT GPIOF
#define CENTER_PIN 8
#define CENTER GPIOF
#define RIGHT_PIN 6
#define RIGHT GPIOE
#define UP_PIN 7
#define UP GPIOF
#define DOWN_PIN 5
#define DOWN GPIOE

//SSD
#define Digit1_PIN 10
#define Digit1 GPIOE
#define Digit2_PIN 7
#define Digit2 GPIOE
#define Digit3_PIN 5
#define Digit3 GPIOB
#define Digit4_PIN 3
#define Digit4 GPIOB
#define DP_PIN 14
#define DP_PORT GPIOF
#define A 9
#define SEG_A GPIOG
#define B 12
#define SEG_B GPIOF
#define C 13
#define SEG_C GPIOF
#define D 14
#define SEG_D GPIOG
#define E 8
#define SEG_E GPIOE
#define F 15
#define SEG_F GPIOF
#define G 4
#define SEG_G GPIOB
