//**********************************************
// * Author: M. Johnson
// * CPEG222 Project 3, 9/26/26
// * NucleoF466ZE CMSIS 
// *
// * Project Description: 
// * Making a timer on SSD controlled by up and down controls.
//**********************************************

#include "MainSetup.h"
#include "PinPortDefs.h"

const unsigned char SSDdigits[] = {
    //SSD is common anode, so 0 = on, 1 = off.

    0b1000000, //0
    0b1111001, //1
    0b0100100, //2
    0b0110000, //3
    0b0011001, //4
    0b0010010, //5
    0b0000010, //6
    0b1111000, //7
    0b0000000, //8
    0b0010000, //9
    0b1111111 //blank or off
};

GPIO_TypeDef* SSD_PORTS[] = {SEG_G,SEG_F,SEG_E,SEG_D,SEG_C,SEG_B,SEG_A};
uint16_t SSD_PINS[] = {1 << G,1 << F,1 << E, 1<< D,1 << C,1 << B, 1 << A}; // Bit masks Pins for MUX
GPIO_TypeDef* DIGIT_PORTS[] = {Digit1,Digit2,Digit3,Digit4};
uint16_t DIGIT_PINS[] = {1 << Digit1_PIN,1 << Digit2_PIN, 1<< Digit3_PIN, 1<< Digit4_PIN};

volatile bool paused = true;
volatile uint16_t state = 0; //Keeps track of current state
volatile uint16_t prev_state = 0; //Previous state
volatile uint16_t current_num = 0;
volatile uint32_t ms_ticks = 0; //Keeps track of milliseconds for SysTick

void rcc_enable(void){
    //Enable clock for GPIOA, GPIOB, GPIOE, and GPIOF
    RCC->AHB1ENR |= (RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN | RCC_AHB1ENR_GPIOEEN | RCC_AHB1ENR_GPIOFEN | RCC_AHB1ENR_GPIOGEN);
    RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN; //Enable Syscfg clock
    RCC->APB1ENR |= RCC_APB1ENR_TIM5EN; //Enable TIM5 clock

    SysTick_Config(SystemCoreClock / 1000); // Configure SysTick for 1ms interrupts

    //Enable TIM5
    TIM5->PSC = 15999; //Prescaler
    TIM5->ARR = 1; //2 ms period Auto-reload for MUX
    TIM5->EGR |= TIM_EGR_UG;
    TIM5->CNT = 0; //Reset counter
    TIM5->DIER |= TIM_DIER_UIE; //Enable update interrupt
    TIM5->SR &= ~TIM_SR_UIF; // Clear pending interrupts


    NVIC_SetPriority(TIM5_IRQn,1);
    NVIC_EnableIRQ(TIM5_IRQn);
    TIM5->CR1 |= TIM_CR1_CEN; //Enable TIM5
}

void SSD_init(void){
    //Digit Registers
    GPIOE->MODER &= ~((0x3 << (Digit1_PIN * 2)) | (0x3 << (Digit2_PIN * 2))); // Leftmost
    GPIOE->MODER |= ((0x1 << (Digit1_PIN * 2)) | (0x1 << (Digit2_PIN * 2)));
    GPIOB->MODER &= ~((0x3 << (Digit3_PIN * 2)) | (0x3 << (Digit4_PIN * 2)));
    GPIOB->MODER |= ((0x1 << (Digit3_PIN * 2))| (0x1 << (Digit4_PIN * 2))); // Rightmost

    //Segment Registers
    GPIOB->MODER &= ~((0x3 << (G * 2)));
    GPIOB->MODER |= ((0x1 << (G * 2)));

    GPIOE->MODER  &= ~((0x3 << (E * 2)));
    GPIOE->MODER |= ((0x1 << (E* 2)));

    GPIOF->MODER &= ~((0x3 << (B * 2)) | (0x3 << (C * 2)) | (0x3 << (F * 2)) | (0x3 << (DP_PIN * 2)));
    GPIOF->MODER |= ((0x1 << (B * 2))| (0x1 << (C * 2))| (0x1 << (F * 2))| (0x1 << (DP_PIN * 2)));

    GPIOG->MODER &= ~((0x3 << (A * 2)) | (0x3 << (D * 2)));
    GPIOG->MODER |= ((0x1 << (A * 2))| (0x1 << (D * 2)));
}

void buttons_init(void){
    //Configure Buttons as Inputs
    GPIOE->MODER &= ~((0x3 << (RIGHT_PIN*2))|(0x3 << (DOWN_PIN*2))); //Clear Mode Bits
    GPIOE->PUPDR &= ~((0x3 << (RIGHT_PIN*2))|(0x3 << (DOWN_PIN*2))); //Clear Mode Bits
    GPIOE->PUPDR |= ((0x1 << (RIGHT_PIN*2))|(0x1 << (DOWN_PIN*2)));

    GPIOF->MODER &= ~((0x3 << (LEFT_PIN*2))|(0x3 << (CENTER_PIN*2))|(0x3 << UP_PIN*2)); //Clear Mode Bits
    GPIOF->PUPDR &= ~((0x3 << (LEFT_PIN*2))|(0x3 << (CENTER_PIN*2))|(0x3 << UP_PIN*2)); //Clear Mode Bits
    GPIOF->PUPDR |= ((0x1 << (LEFT_PIN*2))|(0x1 << (CENTER_PIN*2))|(0x1 << UP_PIN*2));

    //Configuring Interrupts and EXTI Lines
    SYSCFG->EXTICR[1] = 0; //Clear EXTI5, EXTI6, EXTI7
    SYSCFG->EXTICR[1] &= ~((0xFUL << 4)|(0xFUL << 8)|(0xFUL << 12)); //clear EXTI5, EXTI6,EXTI 7
    SYSCFG->EXTICR[1] |= ((0x4UL << 4)|(0x4UL << 8)); //Set EXTI 5-6 to PortE
    SYSCFG->EXTICR[1] |=  (0x5UL << 12); //Set EXTI 7 to PortF

    SYSCFG->EXTICR[2] = 0; //Clear EXTI8, EXTI9
    SYSCFG->EXTICR[2] &= ~((0xFUL << 0) | (0xFUL << 4)); // clear EXTI8, EXTI9
    SYSCFG->EXTICR[2] |= ((0x5UL << 0) | (0x5UL << 4)); //Set EXTI 8-9 to PortF

    //Enable EXTI lines PE5,PE6,PF7,PF8,PF9
    EXTI->IMR |= ((1UL << LEFT_PIN) | (1UL << CENTER_PIN) | (1UL << RIGHT_PIN)|(1UL << UP_PIN) | (1UL<<DOWN_PIN)); //Unmask interrupts
    EXTI->FTSR |= ((1UL << LEFT_PIN) | (1UL << CENTER_PIN) | (1UL << RIGHT_PIN)|(1UL << UP_PIN) | (1UL<<DOWN_PIN)); // Falling Edge Trigger
    EXTI->RTSR &= ~((1UL << LEFT_PIN) | (1UL << CENTER_PIN) | (1UL << RIGHT_PIN)|(1UL << UP_PIN) | (1UL<<DOWN_PIN)); // Turn off Rising Edge Trigger

    NVIC_SetPriority(EXTI9_5_IRQn,2);
    NVIC_EnableIRQ(EXTI9_5_IRQn);
}

void SysTick_Handler(void){
    ms_ticks++;
}

void TIM5_IRQHandler(void){
    if (TIM5->SR & TIM_SR_UIF){
        TIM5->SR &= ~TIM_SR_UIF; // Clear update interrupt 

        refresh(current_num);

        static uint8_t time_div = 0;
        time_div++;

        //2ms*10 = 10ms
        if(time_div >= 5){
            time_div = 0;
            state_machine(); // Update state machine every 10ms
        }
    }
}

void EXTI9_5_IRQHandler(void){ //Interrupt Handler Function
    static uint32_t last_interrupt_time = 0;
    uint32_t current_time = ms_ticks;

    uint32_t pending = EXTI->PR;
    
    if(current_time - last_interrupt_time < 150){ //Debounce time of 150ms
        EXTI->PR = pending & ((1 << LEFT_PIN) | (1 << CENTER_PIN) | (1 << RIGHT_PIN) | (1 << UP_PIN) | (1 << DOWN_PIN)); //clear pending flags
        return; // Ignore this interrupt if it occurred within the debounce time
    }

    //Debounce Button Presses
    if(EXTI->PR & (1 << LEFT_PIN)){
        EXTI->PR = (1 << LEFT_PIN); //Clear pending flag
        state = 3;
        last_interrupt_time = current_time;
    }
    if(EXTI->PR & (1 << CENTER_PIN)){
        EXTI->PR = (1 << CENTER_PIN); //Clear pending flag
        if(state == 1 || state == 2){
            prev_state = state; // Store previous state
        }
        state = 0;
        last_interrupt_time = current_time;
    }
    if(EXTI->PR & (1 << RIGHT_PIN)){
        EXTI->PR = (1 << RIGHT_PIN); //Clear pending flag 
        state = 4;
        last_interrupt_time = current_time;
    }
    if(EXTI->PR & (1 << UP_PIN)){
        EXTI->PR = (1 << UP_PIN);
        state = 1;
        last_interrupt_time = current_time;
    }
    if(EXTI->PR & (1 << DOWN_PIN)){
        EXTI->PR = (1 << DOWN_PIN);
        state = 2;
        last_interrupt_time = current_time;
    }
}

void refresh(uint16_t current_num){
    static uint8_t current_dig = 0;

    for(int i = 0;i < 4 ; i++){
        DIGIT_PORTS[i]->BSRR = (DIGIT_PINS[i]); // Turn off all digits to prevent ghosting
    }

    uint8_t digit_val = 0;
    bool blank = false;


    uint8_t d1 = (current_num / 1000) % 10; // Thousands place
    uint8_t d2 = (current_num / 100) % 10; // Hundreds place
    uint8_t d3 = (current_num / 10) % 10; // Tens place
    uint8_t d4 = current_num % 10; // Ones

    if(current_dig == 0){
        digit_val = d1;
        if(d1 == 0){
            blank = true;
        }
    }else if(current_dig == 1){
        digit_val = d2;
    }else if(current_dig == 2){
        digit_val = d3;
    }else if(current_dig == 3){
        digit_val = d4;
    }
   
    unsigned char pattern = (!blank) ? SSDdigits[digit_val] : SSDdigits[10];

    for(int i = 0; i < 7 ; i++){
        //0 -> ON, 1-> OFF
        if((pattern >> (6-i)) & 1){ //Bit Masking
            SSD_PORTS[i]->BSRR = SSD_PINS[i]; //Turn OFF LED segment goign HIGH
        }else{
            SSD_PORTS[i]->BSRR = (uint32_t)SSD_PINS[i] << 16; //Turn ON LED segment going LOW
        }
    }

    DP_PORT->BSRR = (1 << DP_PIN); // Turn off decimal point to prevent ghosting

    //For decimal
    if(current_dig == 1){
        DP_PORT->BSRR = (1 << (DP_PIN+16)); // DP ON, goes LOW
    }else{
        DP_PORT->BSRR =(1 << DP_PIN); // DP OFF, goes HIGH
    }

    //Turn ON active digit common pin
    if(!blank || current_dig == 3){ // If not blank or not the first digit
        DIGIT_PORTS[current_dig]->BSRR = (DIGIT_PINS[current_dig] << 16); // Turn on active digit
    }
    
    //Next display digit
    current_dig = (current_dig + 1) % 4;
};

void state_machine(void){
    if ((state == 0)){
        paused = true;

        if(prev_state == 1){
           if(current_num >= 9999){
                current_num = 9999;
           }
        }else if(prev_state == 2){
            if(current_num == 0){
                current_num = 0;
            }
        } else if(prev_state == 3){
            current_num = 0;
        }else if(prev_state == 4){
            current_num = 9999;
        }

    }else if (state == 1){ //Moving up
        paused = false;

        if(current_num >= 9999){
            current_num = 9999;
            prev_state = 1;
            state = 0;
        }else{
            current_num++; // Increment
        }
    }else if(state == 2){ // Moving down
        paused = false;

         if(current_num == 0){
            current_num = 0;
            prev_state = 2;
            state = 0;
         }else{
            current_num--; // Decrement
         }
        
    }else if(state == 3){ //Left button pressed
        paused = true;
        prev_state = 3;
        state = 0;

    }else if(state == 4){ //Right button Pressed
        paused = true;
        prev_state = 4;
        state = 0;
    }
}
