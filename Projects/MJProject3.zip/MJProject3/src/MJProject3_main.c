//**********************************************
// * Author: M. Johnson
// * CPEG222 Project 3, 9/26/26
// * NucleoF466ZE CMSIS 
// *
// * Project Description: 
// * Making a timer on SSD controlled by up and down controls.
//**********************************************


//** Imports & Definitions **//
#include "PinPortDefs.h"
#include "MainSetup.h"

int main(void){
    rcc_enable(); //Enables all clock Registers, Timers, & Interrupts
    SSD_init(); // Initialize SSD
    buttons_init(); // Initialize Buttons

    while(1){
        //Does nothing, all work done by interrupts :)
    }
    return 0; // Will never be reached
}
